package com.delivery_api.Projeto.Delivery.API.entity;

public class Restaurante {
}
