package com.delivery_api.Projeto.Delivery.API.controller;

public class PedidoController {
}
