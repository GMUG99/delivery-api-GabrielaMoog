package com.delivery_api.Projeto.Delivery.API.repository;

public class RestaurenteRepository {
}
